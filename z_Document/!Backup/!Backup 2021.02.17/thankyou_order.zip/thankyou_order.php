<!doctype html>
<html>

<head>
	<?php require('inc_head.php'); ?>
	<style>
        .wrap_thx_order{
            width: 700px;
            margin: 0 auto;
            text-align: center;
        }
        .wrap_thx_order .topic_cartinfo{
            margin-bottom: 0;
        }
        .wrap_thx_order .bggrey_thx{
            padding: 30px 100px;
        }
        .wrap_thx_order .topic_bgpurple{
            margin-bottom: 5px;
        }
        
@media (max-width: 1600px){
    .wrap_thx_order{
        width: 100%;
    }
    .wrap_thx_order .bggrey_thx{
        padding: 20px 15px;
    }
}
        
    </style>
</head>

<body>

	<div class="container-fluid footer_notop">
	
		<?php require('inc_menu.php'); ?>

		<section class="row">
		    <div class="container">
                 <div class="row wrap_navigationbar">
                     <a href="index.php"><img src="images/icon_home.svg" alt=""></a>  <span><i class="fas fa-chevron-right"></i></span> <div>Thank you for your order!    </div>
                 </div>
		    </div>
		</section>
		
		
		<section class="row">
		    <div class="container">
		        <div class="row page_cartlogin">
                     <div class="col-12 nopad">
                         <div class="wrap_thx_order wrap_thx">
                             <div class="wrap_frm_register form_cartlogin">
                                <div class="topic_bgpurple thx_bggreen">
                                     <div class="topic_cartinfo">Thank You</div>
                                 </div>
                                 <div class="bggrey_thx">
                                     <p>
                                         Your order is being processed by eatfit team and you should receive a confirmation from us shortly.
                                     </p>
                                     <p>
                                         Enjoy your eatfit experience!!
                                     </p>
                                 </div>
                                 
                               
                                 <div class="row">
                                              <div class="col-12 text-center">
                                                   <a href="index.php" class="btn_default btn_green">Continue Shopping</a>
                                              </div>
                                          </div>
                                 
                             </div>
                         </div>
                     </div>
		        </div>
		    </div>
		</section>
		
		
		<?php require('inc_footer.php'); ?>
		<?php require('scriptjs.php'); ?>
		
	</div>

	
	

</body>

</html>
